create view V_$SYSTEM_WAIT_CLASS as
select "WAIT_CLASS_ID","WAIT_CLASS#","WAIT_CLASS","TOTAL_WAITS","TIME_WAITED" from v$system_wait_class
