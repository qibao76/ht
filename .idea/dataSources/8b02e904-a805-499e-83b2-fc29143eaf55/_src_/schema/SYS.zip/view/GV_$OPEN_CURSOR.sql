create view GV_$OPEN_CURSOR as
select "INST_ID","SADDR","SID","USER_NAME","ADDRESS","HASH_VALUE","SQL_ID","SQL_TEXT" from gv$open_cursor
