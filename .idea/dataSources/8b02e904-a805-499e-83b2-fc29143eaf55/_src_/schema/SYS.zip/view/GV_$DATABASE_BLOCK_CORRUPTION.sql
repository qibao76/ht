create view GV_$DATABASE_BLOCK_CORRUPTION as
select "INST_ID","FILE#","BLOCK#","BLOCKS","CORRUPTION_CHANGE#","CORRUPTION_TYPE" from
   gv$database_block_corruption
