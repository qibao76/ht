create view V_$PARALLEL_DEGREE_LIMIT_MTH as
select "NAME" from v$parallel_degree_limit_mth
