create view V_$FLASHBACK_DATABASE_LOGFILE as
select "NAME","LOG#","THREAD#","SEQUENCE#","BYTES","FIRST_CHANGE#","FIRST_TIME" from v$flashback_database_logfile
