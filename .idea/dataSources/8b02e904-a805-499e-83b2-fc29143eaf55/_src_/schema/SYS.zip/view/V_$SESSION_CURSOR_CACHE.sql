create view V_$SESSION_CURSOR_CACHE as
select "MAXIMUM","COUNT","OPENED_ONCE","OPEN","OPENS","HITS","HIT_RATIO" from v$session_cursor_cache
