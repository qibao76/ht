create view GV_$BACKUP_DEVICE as
select "INST_ID","DEVICE_TYPE","DEVICE_NAME" from gv$backup_device
