create view GV_$ARCHIVE as
select "INST_ID","GROUP#","THREAD#","SEQUENCE#","ISCURRENT","CURRENT","FIRST_CHANGE#" from gv$archive
