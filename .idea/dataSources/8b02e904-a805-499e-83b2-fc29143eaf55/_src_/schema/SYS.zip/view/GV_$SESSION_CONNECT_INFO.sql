create view GV_$SESSION_CONNECT_INFO as
select "INST_ID","SID","AUTHENTICATION_TYPE","OSUSER","NETWORK_SERVICE_BANNER" from gv$session_connect_info
