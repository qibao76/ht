create view V_$SQL_OPTIMIZER_ENV as
select "ADDRESS","HASH_VALUE","SQL_ID","CHILD_ADDRESS","CHILD_NUMBER","ID","NAME","ISDEFAULT","VALUE" from v$sql_optimizer_env
