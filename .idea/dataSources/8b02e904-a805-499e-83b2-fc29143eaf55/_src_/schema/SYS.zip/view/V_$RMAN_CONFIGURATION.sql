create view V_$RMAN_CONFIGURATION as
select "CONF#","NAME","VALUE" from v$rman_configuration
