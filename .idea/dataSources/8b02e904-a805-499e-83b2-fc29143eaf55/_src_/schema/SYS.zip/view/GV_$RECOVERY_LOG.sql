create view GV_$RECOVERY_LOG as
select "INST_ID","THREAD#","SEQUENCE#","TIME","ARCHIVE_NAME" from gv$recovery_log
