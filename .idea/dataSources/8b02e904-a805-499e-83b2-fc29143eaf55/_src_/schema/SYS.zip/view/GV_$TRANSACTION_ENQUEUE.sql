create view GV_$TRANSACTION_ENQUEUE as
select "INST_ID","ADDR","KADDR","SID","TYPE","ID1","ID2","LMODE","REQUEST","CTIME","BLOCK" from gv$transaction_enqueue
