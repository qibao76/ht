create view V_$SYS_OPTIMIZER_ENV as
select "ID","NAME","ISDEFAULT","VALUE","DEFAULT_VALUE" from v$sys_optimizer_env
