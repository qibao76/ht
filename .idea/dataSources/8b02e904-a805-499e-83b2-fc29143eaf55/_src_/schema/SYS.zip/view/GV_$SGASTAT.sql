create view GV_$SGASTAT as
select "INST_ID","POOL","NAME","BYTES" from gv$sgastat
