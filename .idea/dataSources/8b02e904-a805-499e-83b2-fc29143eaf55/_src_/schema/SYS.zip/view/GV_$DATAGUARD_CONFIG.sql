create view GV_$DATAGUARD_CONFIG as
select "DB_UNIQUE_NAME" from gv$dataguard_config
