create view V_$SGA as
select "NAME","VALUE" from v$sga
