create view V_$EVENT_HISTOGRAM as
select "EVENT#","EVENT","WAIT_TIME_MILLI","WAIT_COUNT" from v$event_histogram
