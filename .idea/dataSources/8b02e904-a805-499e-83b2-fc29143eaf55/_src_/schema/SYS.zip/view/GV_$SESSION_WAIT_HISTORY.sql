create view GV_$SESSION_WAIT_HISTORY as
select "INST_ID","SID","SEQ#","EVENT#","EVENT","P1TEXT","P1","P2TEXT","P2","P3TEXT","P3","WAIT_TIME","WAIT_COUNT" from gv$session_wait_history
