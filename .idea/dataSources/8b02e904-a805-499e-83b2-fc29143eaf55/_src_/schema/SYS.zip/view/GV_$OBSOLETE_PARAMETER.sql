create view GV_$OBSOLETE_PARAMETER as
select "INST_ID","NAME","ISSPECIFIED" from gv$obsolete_parameter
