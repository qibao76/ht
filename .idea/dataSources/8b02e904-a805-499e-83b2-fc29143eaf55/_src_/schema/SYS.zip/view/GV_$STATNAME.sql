create view GV_$STATNAME as
select "INST_ID","STATISTIC#","NAME","CLASS","STAT_ID" from gv$statname
