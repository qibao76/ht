create view GV_$PWFILE_USERS as
select "INST_ID","USERNAME","SYSDBA","SYSOPER" from gv$pwfile_users
