create view GV_$ARCHIVE_PROCESSES as
select "INST_ID","PROCESS","STATUS","LOG_SEQUENCE","STATE" from gv$archive_processes
