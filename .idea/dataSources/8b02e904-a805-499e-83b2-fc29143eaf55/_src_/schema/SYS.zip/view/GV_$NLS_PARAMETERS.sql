create view GV_$NLS_PARAMETERS as
select "INST_ID","PARAMETER","VALUE" from gv$nls_parameters
