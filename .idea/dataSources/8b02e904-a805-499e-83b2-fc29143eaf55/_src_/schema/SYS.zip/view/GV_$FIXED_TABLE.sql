create view GV_$FIXED_TABLE as
select "INST_ID","NAME","OBJECT_ID","TYPE","TABLE_NUM" from gv$fixed_table
