create view GV_$INDEXED_FIXED_COLUMN as
select "INST_ID","TABLE_NAME","INDEX_NUMBER","COLUMN_NAME","COLUMN_POSITION" from gv$indexed_fixed_column
