create view V_$CONTROLFILE as
select "STATUS","NAME","IS_RECOVERY_DEST_FILE","BLOCK_SIZE","FILE_SIZE_BLKS" from v$controlfile
