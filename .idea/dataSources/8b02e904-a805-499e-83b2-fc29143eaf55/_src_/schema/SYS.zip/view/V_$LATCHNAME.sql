create view V_$LATCHNAME as
select "LATCH#","NAME","HASH" from v$latchname
