create view V_$ARCHIVE as
select "GROUP#","THREAD#","SEQUENCE#","ISCURRENT","CURRENT","FIRST_CHANGE#" from v$archive
