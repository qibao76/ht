create view GV_$EVENT_HISTOGRAM as
select "INST_ID","EVENT#","EVENT","WAIT_TIME_MILLI","WAIT_COUNT" from gv$event_histogram
