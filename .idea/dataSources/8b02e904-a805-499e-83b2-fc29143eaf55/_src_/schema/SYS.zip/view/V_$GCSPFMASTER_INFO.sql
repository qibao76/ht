create view V_$GCSPFMASTER_INFO as
select "FILE_ID","OBJECT_ID","CURRENT_MASTER","PREVIOUS_MASTER","REMASTER_CNT" from v$gcspfmaster_info
