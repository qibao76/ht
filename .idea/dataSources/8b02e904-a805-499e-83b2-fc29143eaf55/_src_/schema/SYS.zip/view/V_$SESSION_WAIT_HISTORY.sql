create view V_$SESSION_WAIT_HISTORY as
select "SID","SEQ#","EVENT#","EVENT","P1TEXT","P1","P2TEXT","P2","P3TEXT","P3","WAIT_TIME","WAIT_COUNT" from v$session_wait_history
