create view GV_$SESSION_WAIT_CLASS as
select "INST_ID","SID","SERIAL#","WAIT_CLASS_ID","WAIT_CLASS#","WAIT_CLASS","TOTAL_WAITS","TIME_WAITED" from gv$session_wait_class
