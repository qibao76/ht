create view GV_$ARCHIVE_GAP as
select "INST_ID","THREAD#","LOW_SEQUENCE#","HIGH_SEQUENCE#" from gv$archive_gap
