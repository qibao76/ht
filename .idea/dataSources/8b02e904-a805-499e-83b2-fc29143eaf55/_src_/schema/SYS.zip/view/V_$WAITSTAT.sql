create view V_$WAITSTAT as
select "CLASS","COUNT","TIME" from v$waitstat
