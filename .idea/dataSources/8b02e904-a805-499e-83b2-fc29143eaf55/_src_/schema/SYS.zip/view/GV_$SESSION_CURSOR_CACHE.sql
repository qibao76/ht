create view GV_$SESSION_CURSOR_CACHE as
select "INST_ID","MAXIMUM","COUNT","OPENED_ONCE","OPEN","OPENS","HITS","HIT_RATIO" from gv$session_cursor_cache
