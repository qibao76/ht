create view GV_$RECOVER_FILE as
select "INST_ID","FILE#","ONLINE","ONLINE_STATUS","ERROR","CHANGE#","TIME" from gv$recover_file
