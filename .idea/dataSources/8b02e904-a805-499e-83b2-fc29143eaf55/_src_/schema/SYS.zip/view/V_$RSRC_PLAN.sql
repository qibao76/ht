create view V_$RSRC_PLAN as
select "ID","NAME","IS_TOP_PLAN" from v$rsrc_plan
