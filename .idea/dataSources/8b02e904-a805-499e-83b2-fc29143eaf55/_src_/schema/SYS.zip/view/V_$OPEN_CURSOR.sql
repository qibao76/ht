create view V_$OPEN_CURSOR as
select "SADDR","SID","USER_NAME","ADDRESS","HASH_VALUE","SQL_ID","SQL_TEXT" from v$open_cursor
