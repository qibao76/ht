create view V_$SHARED_SERVER as
select "NAME","PADDR","STATUS","MESSAGES","BYTES","BREAKS","CIRCUIT","IDLE","BUSY","REQUESTS" from v$shared_server
