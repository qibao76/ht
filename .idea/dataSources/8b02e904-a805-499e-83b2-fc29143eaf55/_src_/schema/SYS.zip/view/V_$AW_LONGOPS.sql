create view V_$AW_LONGOPS as
select "SESSION_ID","CURSOR_NAME","COMMAND","STATUS","ROWS_PROCESSED","START_TIME" from v$aw_longops
