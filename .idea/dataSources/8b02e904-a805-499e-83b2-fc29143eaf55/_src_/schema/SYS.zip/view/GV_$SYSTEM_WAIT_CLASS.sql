create view GV_$SYSTEM_WAIT_CLASS as
select "INST_ID","WAIT_CLASS_ID","WAIT_CLASS#","WAIT_CLASS","TOTAL_WAITS","TIME_WAITED" from gv$system_wait_class
