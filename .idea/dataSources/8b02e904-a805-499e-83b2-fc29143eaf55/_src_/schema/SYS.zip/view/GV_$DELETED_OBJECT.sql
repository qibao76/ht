create view GV_$DELETED_OBJECT as
select "INST_ID","RECID","STAMP","TYPE","OBJECT_RECID","OBJECT_STAMP","OBJECT_DATA" from gv$deleted_object
