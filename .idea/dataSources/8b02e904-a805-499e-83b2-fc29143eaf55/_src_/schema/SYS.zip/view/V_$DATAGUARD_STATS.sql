create view V_$DATAGUARD_STATS as
select "NAME","VALUE","UNIT","TIME_COMPUTED" from v$dataguard_stats
