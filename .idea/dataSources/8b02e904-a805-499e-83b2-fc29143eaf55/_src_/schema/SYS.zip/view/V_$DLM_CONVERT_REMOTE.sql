create view V_$DLM_CONVERT_REMOTE as
select "INST_ID","CONVERT_TYPE","AVERAGE_CONVERT_TIME","CONVERT_COUNT" from v$dlm_convert_remote
