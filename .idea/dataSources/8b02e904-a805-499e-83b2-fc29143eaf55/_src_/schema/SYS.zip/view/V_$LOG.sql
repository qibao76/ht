create view V_$LOG as
select "GROUP#","THREAD#","SEQUENCE#","BYTES","MEMBERS","ARCHIVED","STATUS","FIRST_CHANGE#","FIRST_TIME" from v$log
