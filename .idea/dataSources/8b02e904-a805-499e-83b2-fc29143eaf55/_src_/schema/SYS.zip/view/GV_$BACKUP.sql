create view GV_$BACKUP as
select "INST_ID","FILE#","STATUS","CHANGE#","TIME" from gv$backup
