create view GV_$SUBCACHE as
select "INST_ID","OWNER_NAME","NAME","TYPE","HEAP_NUM","CACHE_ID","CACHE_CNT","HEAP_SZ","HEAP_ALOC","HEAP_USED" from gv$subcache
