create view V_$TEMP_HISTOGRAM as
select "FILE#","SINGLEBLKRDTIM_MILLI","SINGLEBLKRDS" from v$temp_histogram
