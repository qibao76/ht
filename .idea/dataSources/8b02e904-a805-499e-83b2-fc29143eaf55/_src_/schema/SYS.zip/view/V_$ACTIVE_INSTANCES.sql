create view V_$ACTIVE_INSTANCES as
select "INST_NUMBER","INST_NAME" from v$active_instances
