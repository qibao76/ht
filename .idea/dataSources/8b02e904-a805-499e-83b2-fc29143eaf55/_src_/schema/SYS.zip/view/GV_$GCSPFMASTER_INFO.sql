create view GV_$GCSPFMASTER_INFO as
select "INST_ID","FILE_ID","OBJECT_ID","CURRENT_MASTER","PREVIOUS_MASTER","REMASTER_CNT" from gv$gcspfmaster_info
