create view GV_$MYSTAT as
select "INST_ID","SID","STATISTIC#","VALUE" from gv$mystat
