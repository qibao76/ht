create view V_$MUTEX_SLEEP as
select "MUTEX_TYPE","LOCATION","SLEEPS","WAIT_TIME" from v$mutex_sleep
