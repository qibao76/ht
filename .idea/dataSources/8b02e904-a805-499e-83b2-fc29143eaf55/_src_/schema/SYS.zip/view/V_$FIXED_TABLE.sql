create view V_$FIXED_TABLE as
select "NAME","OBJECT_ID","TYPE","TABLE_NUM" from v$fixed_table
