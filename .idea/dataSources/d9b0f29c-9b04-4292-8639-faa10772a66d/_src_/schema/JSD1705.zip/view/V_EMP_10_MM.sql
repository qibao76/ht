create view V_EMP_10_MM as
SELECT empno ID,ename NAME,sal salary,deptno
from emp_mm where deptno=10 with read only
