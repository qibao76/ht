create view V_EMP_MW as
SeleCT EMPNO ID ,ENAME NAME,SAL SALARY,DEPTNO From Employee_Mwu
WITH read  only
