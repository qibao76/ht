create view V_EMP_CHENJUN as
SELECT empno id,ename name,sal salary,deptno
FROM e_emp_chenjun
WHERE deptno=10
