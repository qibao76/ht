create view V_EMP_GP as
select empno id,ename name,sal salary, deptno
from emp_gp
where deptno=10
with read only
