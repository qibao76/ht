create view V_EMP_JODY_10 as
SELECT empno ID,ename NAME,sal salary,deptno
FROM emp_jody
WHERE deptno=10
WITH READ ONLY
