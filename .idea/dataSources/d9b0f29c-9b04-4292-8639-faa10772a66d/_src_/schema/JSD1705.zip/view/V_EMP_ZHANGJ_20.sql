create view V_EMP_ZHANGJ_20 as
select empno,ename,sal,job,deptno
from emp
where deptno=20
