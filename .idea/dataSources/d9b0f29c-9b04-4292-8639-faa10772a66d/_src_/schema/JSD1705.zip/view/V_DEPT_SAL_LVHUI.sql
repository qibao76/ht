create view V_DEPT_SAL_LVHUI as
SELECT d.deptno,d.dname,
       MAX(e.sal) max_sal,
       MIN(e.sal) min_sal,
       SUM(e.sal) sum_sal,
       AVG(e.sal) avg_sal
FROM emp_lvhui e,dept_lvhui d
WHERE e.deptno=d.deptno
GROUP BY d.deptno,d.dname
