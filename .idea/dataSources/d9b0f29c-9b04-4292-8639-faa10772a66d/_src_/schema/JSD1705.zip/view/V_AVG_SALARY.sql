create view V_AVG_SALARY as
SELECT d.depton,d.dname,
      MAX(e.salary) max_sal,
      MIN(e.salary) min_sal,
      SUM(e.salary) sum_sal,
      AVG(e.salary) avg_sal
FROM emp_fangchengW e,dept_fangchengW d
WHERE e.deptno=d.depton
GROUP BY d.depton,d.dname
