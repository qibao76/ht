create view V_EMP_10_ZHQ as
select empno,ename,sal,deptno
  from emp_zhouhuaqiang
  where deptno=10
