create view V_EMP_TANGMIN as
SELECT empno,ename,sal,job,deptno FROM emp_mintang WHERE deptno=20
