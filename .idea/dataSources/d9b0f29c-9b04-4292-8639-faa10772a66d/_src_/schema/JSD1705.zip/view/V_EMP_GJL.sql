create view V_EMP_GJL as
SELECT empno id,ename name,sal salary,deptno FROM emp_gjl WHERE deptno=10 
WITH READ ONLY
