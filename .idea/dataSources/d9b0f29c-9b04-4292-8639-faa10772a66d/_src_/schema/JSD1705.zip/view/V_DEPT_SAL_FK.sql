create view V_DEPT_SAL_FK as
SELECT d.deptno,d.dname,
          MAX(e.sal) max_sal,
          MIN(e.sal) min_sal,
          AVG(e.sal) avg_sal
FROM emp_Fk e, dept_Fk d
WHERE e.deptno=d.deptno
GROUP BY d.deptno,d.dname
