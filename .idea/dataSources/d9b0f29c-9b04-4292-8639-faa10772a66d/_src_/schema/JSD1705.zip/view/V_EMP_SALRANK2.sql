create view V_EMP_SALRANK2 as
select ename,2 工资级别 from emp_cjf where sal<3000 and sal>2000
