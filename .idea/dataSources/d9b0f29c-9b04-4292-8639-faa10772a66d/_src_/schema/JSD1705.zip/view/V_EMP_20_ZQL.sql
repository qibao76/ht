create view V_EMP_20_ZQL as
SELECT empno,ename,sal,job,deptno
FROM emp_zql
WHERE deptno=20
