create view V_EMP_SAL_ZMY as
SELECT d.dname, avg(e.sal) avg_sal, sum(e.sal) sum_sal, 
    max(e.sal) max_sal, min(e.sal) min_sal 
    FROM emp e , dept d
    WHERE e.deptno = d.deptno
    GROUP BY d.dname
