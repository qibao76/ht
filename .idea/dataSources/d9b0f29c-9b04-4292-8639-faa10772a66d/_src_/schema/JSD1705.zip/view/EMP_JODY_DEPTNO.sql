create view EMP_JODY_DEPTNO as
SELECT empno,ename,sal,JOB,deptno
FROM emp_jody
WHERE deptno=20
