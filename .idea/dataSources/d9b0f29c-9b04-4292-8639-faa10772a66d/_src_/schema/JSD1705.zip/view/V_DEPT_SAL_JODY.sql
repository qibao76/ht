create view V_DEPT_SAL_JODY as
SELECT d.deptno,d.dname,MAX(e.sal) max_sal,MIN(e.sal) min_sal,avg(e.sal) avg_sal,sum(e.sal) sum_sal
FROM emp_jody e,dept_jody d
WHERE e.deptno=d.deptno
GROUP BY d.deptno,d.dname
