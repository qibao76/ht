create view V_EMP_20_ZOUJUN as
SELECT empno,ename,sal,job,deptno
FROM emp_zoujun WHERE deptno=20
