create view V_EMP_20_FK as
SELECT empno,ename,sal,job,deptno
FROM emp_Fk WHERE deptno=20
