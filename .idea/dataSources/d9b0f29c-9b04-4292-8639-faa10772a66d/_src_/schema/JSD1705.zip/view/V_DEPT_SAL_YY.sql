create view V_DEPT_SAL_YY as
SELECT d.deptno,d.dname,
          MAX(sal) max_sal,
          MIN(sal) min_sal,
          SUM(sal) sum_sal,
          AVG(sal) avg_sal
FROM emp_yiming e,dept_yiming d
WHERE e.deptno=d.deptno
GROUP BY d.deptno,d.dname
