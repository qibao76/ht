create view V_EMP_SALRANK1 as
select ename,1 工资级别 from emp_cjf where sal>=3000
