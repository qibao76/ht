create view V_EMP_20_LZQ as
SELECT empno,ename,sal,job,deptno
FROM emp_LZQ 
WHERE deptno=20
