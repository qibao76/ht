create view V_EMP_20_WXY as
select empno,ename,sal,job,deptno
from emp_wxy where deptno=20
