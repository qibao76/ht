create view QWE1 as
SELECT empno,ename,sal,job,deptno FROM emp_dongboxueying WHERE deptno=20
