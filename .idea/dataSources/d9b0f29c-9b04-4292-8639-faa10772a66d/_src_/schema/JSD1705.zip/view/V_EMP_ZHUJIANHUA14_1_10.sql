create view V_EMP_ZHUJIANHUA14_1_10 as
SELECT empno id,ename name,sal salary,deptno
   FROM emp_zhujianhua14_1
   WHERE deptno=10
   WITH CHECK OPTION
