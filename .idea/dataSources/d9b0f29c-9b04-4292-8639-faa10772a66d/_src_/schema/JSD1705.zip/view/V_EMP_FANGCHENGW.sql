create view V_EMP_FANGCHENGW as
SELECT empno id,ename name,salary,deptno
FROM emp_fangChengW
WHERE deptno=10
WITH CHECK OPTION
