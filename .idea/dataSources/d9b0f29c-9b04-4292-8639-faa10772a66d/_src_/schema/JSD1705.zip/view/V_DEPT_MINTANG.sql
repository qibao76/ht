create view V_DEPT_MINTANG as
SELECT d.deptno,d.dname,MAX(e.sal) max_sal,MIN(e.sal) min_sal,
SUM(e.sal) sum_sal,AVG(e.sal) avg_sal FROM emp_mintang e,dept_mintang d WHERE e.deptno=d.deptno
GROUP BY d.deptno,d.dname
