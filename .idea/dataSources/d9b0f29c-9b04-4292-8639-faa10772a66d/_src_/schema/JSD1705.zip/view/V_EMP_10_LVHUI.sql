create view V_EMP_10_LVHUI as
SELECT empno id,ename name,sal salary,deptno
FROM emp_lvhui
WHERE deptno=10
WITH READ ONLY
