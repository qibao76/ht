create view V_EMP_10_AGV as
SELECT empno id,ename name,sal salary,deptno
FROM employee_AGV
WHERE deptno=10
