create view V_EMP_20_SYJ as
SELECT empno,ename,sal,job,deptno
FROM emp_syj
WHERE deptno=20
