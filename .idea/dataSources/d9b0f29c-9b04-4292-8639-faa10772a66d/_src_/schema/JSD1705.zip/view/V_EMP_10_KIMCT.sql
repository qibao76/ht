create view V_EMP_10_KIMCT as
Select Empno,Ename,Sal,Deptno
From Emp_Kimct
where deptno = 10
