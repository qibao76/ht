create view V_RMP_MRP10 as
select empno id,ename name,sal salary,deptno from emp_MRP
where deptno=10  with read only
