create view V_EMP_10_ZMY as
SELECT empno id,ename name,sal salary,deptno
     from emp_ZMY
     where deptno=10
     WITH CHECK OPTION
