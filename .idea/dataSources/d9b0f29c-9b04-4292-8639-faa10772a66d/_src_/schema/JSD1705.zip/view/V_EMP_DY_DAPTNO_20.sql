create view V_EMP_DY_DAPTNO_20 as
SELECT empno,ename,sal,JOB,daptno
FROM emp_dy
WHERE daptno=20
