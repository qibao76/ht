create view V_EMP_10MIN as
select empno id,ename name,sal salary,deptno
from emp_min
where deptno=10
with read only
