create view V_EMP_20_36 as
SELECT empno,ename,sal,job,deptno
FROM emp_36
WHERE deptno=20
