create view V_HYB as
select empno id,ename name,sal salary,deptno
from hyb
where deptno=10
