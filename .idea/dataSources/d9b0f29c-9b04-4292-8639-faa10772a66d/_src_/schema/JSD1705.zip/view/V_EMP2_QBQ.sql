create view V_EMP2_QBQ as
select empno,ename,job,deptno
from emp_qbq
where deptno=20
