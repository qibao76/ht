create view V_DEPT_SAL_CJF as
select d.deptno,d.dname,
        max(E.SAL) MAX_SAL,
        MIN(E.SAL) MIN_SAL,
        SUM(E.SAL) SUM_SAL,
        AVG(E.SAL) AVG_SAL
FROM EMP_CJF E,DEPT_CJF D
WHERE E.DEPTNO=D.DEPTNO
GROUP BY D.DEPTNO,D.DNAME
