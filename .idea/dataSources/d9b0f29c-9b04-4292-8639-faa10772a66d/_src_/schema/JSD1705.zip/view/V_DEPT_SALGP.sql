create view V_DEPT_SALGP as
select d.deptno,d.dname,
       max(e.sal) msx_sal,
       min(e.sal) min_sal,
       sum(e.sal) sum_sal,
       avg(e.sal) avg_sal
from emp_gp e,dept_guopeng d
where e.deptno=d.deptno
group by d.deptno,d.dname
