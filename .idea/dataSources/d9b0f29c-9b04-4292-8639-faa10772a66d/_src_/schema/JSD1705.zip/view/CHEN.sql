create view CHEN as
SELECT empno,ename,sal,deptno
   FROM jun
   WHERE deptno=10
