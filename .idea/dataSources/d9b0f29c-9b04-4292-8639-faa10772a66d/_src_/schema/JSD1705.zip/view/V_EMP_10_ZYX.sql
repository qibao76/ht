create view V_EMP_10_ZYX as
SELECT empno,ename,sal,job,deptno
FROM emp_zyx
WHERE deptno=20
