create view V_KK as
SELECT empno,ename,sal,job,deptno FROM emp_yiming WHERE deptno=20
