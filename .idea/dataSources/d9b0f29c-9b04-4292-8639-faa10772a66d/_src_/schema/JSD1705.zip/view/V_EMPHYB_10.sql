create view V_EMPHYB_10 as
select empno id,ename name,sal salary,deptno
from emp
where deptno=10
