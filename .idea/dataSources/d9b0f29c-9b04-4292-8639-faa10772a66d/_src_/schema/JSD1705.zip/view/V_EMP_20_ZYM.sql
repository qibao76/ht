create view V_EMP_20_ZYM as
SELECT empno,ename,sal,job,deptno FROM emp_zym13 WHERE deptno=20
