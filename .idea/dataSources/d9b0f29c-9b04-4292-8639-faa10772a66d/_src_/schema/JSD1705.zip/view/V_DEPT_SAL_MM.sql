create view V_DEPT_SAL_MM as
SELECT d.deptno,d.dname,
           MAX(sal) max_sal,
           MIN(sal) min_sal,
           sum(sal) sum_sal,
           avg(sal) avg_sal
FROM emp_mm e,dept d
where e.deptno=d.deptno
group by d.dname,d.deptno
