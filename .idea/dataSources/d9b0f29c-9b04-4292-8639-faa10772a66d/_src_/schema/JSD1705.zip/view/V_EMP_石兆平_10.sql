create view "V_EMP_石兆平_10" as
SELECT empno id,ename name,sal salary,deptno FROM emp_石兆平 WHERE deptno=10
WITH READ ONLY
