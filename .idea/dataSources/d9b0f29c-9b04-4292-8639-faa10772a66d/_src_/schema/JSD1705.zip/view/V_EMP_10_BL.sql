create view V_EMP_10_BL as
SELECT empno,ename,sal,deptno
FROM emp
WHERE deptno=10
