create view V_DEPDTNO_SAL_WDD as
select d.deptno,d.dname,max(sal) ma,min(sal) mi,avg(sal) av
from emp_wdd e join dept_wdd d on e.deptno=d.deptno
group by d.deptno,d.dname
