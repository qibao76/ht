create view V_EMP_QBQ_10 as
SELECT empno id,ename name,sal salary,deptno
from emp_qbq
where deptno=10
with read only
