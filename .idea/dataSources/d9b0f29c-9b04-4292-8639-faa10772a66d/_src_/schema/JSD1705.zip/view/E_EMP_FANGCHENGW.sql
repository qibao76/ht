create view E_EMP_FANGCHENGW as
SELECT empno,ename,salary,deptno
FROM emp_fangChengW
WHERE deptno = 10
