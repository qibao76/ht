create view V_DEPT_SAL_DY as
SELECT d.deptno,d.dname,MAX(e.sal) max_sal,
        MIN(e.sal) min_sal,sum(e.sal) sum_sal,
        avg(e.sal) avg_sal
FROM emp_dy e,dept_dy d
WHERE e.daptno=d.deptno
GROUP BY d.deptno,d.dname
