create view EMP_HAO66_20 as
select empno,ename,sal,job,deptno
from emp_hao66
where deptno=20
