create view V_EMP_10_CBA as
SELECT empno id,ename name,sal salary,deptno
FROM employee_AGV
WHERE deptno=10
WITH CHECK OPTION
