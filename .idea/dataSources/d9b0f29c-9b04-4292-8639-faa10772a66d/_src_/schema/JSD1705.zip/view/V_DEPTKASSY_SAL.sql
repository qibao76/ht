create view V_DEPTKASSY_SAL as
SELECT d.deptno,d.dname,
      MAX(e.sal) max_sal,
      MIN(e.sal) min_sal,
      SUM(e.sal) sum_sal,
      avg(e.sal) avg_sal
FROM emp_Kassy e,dept_Kassy d
where e.deptno=d.deptno
GROUP BY d.deptno,d.dname
