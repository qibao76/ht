create view V_EMP_LVHUI_20 as
SELECT empno,ename,sal,job,deptno
FROM emp_lvhui
WHERE deptno=20
