create view V_EMP_MRP20 as
select empno,ename,sal,job,deptno from emp_MRP where deptno=20
