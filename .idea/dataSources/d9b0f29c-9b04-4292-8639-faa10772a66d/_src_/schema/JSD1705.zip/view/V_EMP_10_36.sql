create view V_EMP_10_36 as
SELECT empno id,ename name,sal salary,deptno
FROM emp_36
WHERE deptno=10
WITH READ ONLY
