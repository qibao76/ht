create view V_EMPG_10 as
select empno,ename,sal,job,deptno
from emp_gp
where deptno =10
