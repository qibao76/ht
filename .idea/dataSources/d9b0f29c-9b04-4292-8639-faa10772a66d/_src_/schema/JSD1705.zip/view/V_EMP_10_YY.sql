create view V_EMP_10_YY as
SELECT empno id,ename name, sal salary,deptno
FROM emp_yiming WHERE deptno=10
WITH READ ONLY
