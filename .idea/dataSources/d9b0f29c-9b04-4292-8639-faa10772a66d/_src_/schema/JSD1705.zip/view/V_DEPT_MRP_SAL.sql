create view V_DEPT_MRP_SAL as
select d.deptno,d.dname,max(e.sal) max_sal,min(e.sal) min_sal,sum(sal) sum_sal,avg(sal) avg_sal
from emp_MRP e,dept_MRP d
where e.deptno=d.deptno  group by d.deptno,d.dname
