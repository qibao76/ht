create view V_EMP_20 as
select empno,enname,sal,job,deptno
  from emp_txj
  where deptno=20
