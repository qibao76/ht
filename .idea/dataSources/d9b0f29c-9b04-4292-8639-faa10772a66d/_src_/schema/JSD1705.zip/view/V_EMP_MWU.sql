create view V_EMP_MWU as
select empno,ename,sal,job,deptno
from Employee_Mwu
where deptno=20
