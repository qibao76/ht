create view V_DEPT_SAL_QBQ as
select d.deptno,d.dname,
      max(sal)max_sal,
      min(sal)min_sal,
      avg(sal)avg_sal,
      sum(sal)sum_sal
from emp_qbq e,dept_qbq d
where e.deptno=d.deptno
group by d.deptno,d.dname
