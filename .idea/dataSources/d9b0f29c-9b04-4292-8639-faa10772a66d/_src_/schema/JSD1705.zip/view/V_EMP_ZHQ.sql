create view V_EMP_ZHQ as
SELECT empno,ename,sal,job,deptno
  from emp_zhouhuaqiang
  where deptno=20
