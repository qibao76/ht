create view VIEW_KEY as
SELECT emp_keyno,ename,sal,job,deptno
FROM emp_key
WHERE deptno = 10
