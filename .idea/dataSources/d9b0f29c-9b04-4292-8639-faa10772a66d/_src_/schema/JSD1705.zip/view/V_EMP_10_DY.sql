create view V_EMP_10_DY as
SELECT empno ID,ename NAME,sal salary,daptno
FROM emp_dy
WHERE daptno=10
WITH CHECK OPTION
