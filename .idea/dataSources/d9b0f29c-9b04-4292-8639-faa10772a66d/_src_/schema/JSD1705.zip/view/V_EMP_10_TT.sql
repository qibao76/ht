create view V_EMP_10_TT as
select empno id,enname name,sal salary,deptno
from emp_txj
where deptno=10
with read only
