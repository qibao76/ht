create view V_EMP_20_SCH as
SELECT empno,ename,sal,job,deptno
FROM emp_sch
WHERE deptno=20
