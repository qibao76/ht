create view V_DEPT_SAL_YUAN as
select d.deptno,d.dname,max(e.sal) max_sal,min(sal) min_sal,sum(sal) sum_sal,
avg(sal) avg_sal from emp e,dept d
where e.deptno=d.deptno
group by d.deptno,d.dname
