create view V_EMP_20_HS as
select empno,ename,sal,job,deptno
from emp_hs
where deptno = 20
