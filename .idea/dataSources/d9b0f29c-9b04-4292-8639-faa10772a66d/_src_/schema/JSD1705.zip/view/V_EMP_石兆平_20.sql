create view "V_EMP_石兆平_20" as
SELECT empno,ename,sal,job,deptno FROM emp_石兆平
WHERE deptno=20
