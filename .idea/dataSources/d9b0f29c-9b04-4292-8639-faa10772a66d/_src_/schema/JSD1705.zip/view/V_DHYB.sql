create view V_DHYB as
select e.deptno,d.dname,
       max(sal) max_sal,
       min(sal) min_sal,
       avg(sal) avg_sal,
       sum(sal) sum_sal
from hyb e,dhyb d
where e.deptno=d.deptno
group by e.deptno,d.dname
