create view V_EMPGP_10 as
select empno,ename,sal,deptno
from emp_gp
where deptno=10
