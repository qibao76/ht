create view V_EMP_SALRANK3 as
select ename,3 工资级别 from emp_cjf where sal<=2000
