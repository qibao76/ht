create view V_EMP_ZZ as
select empno,ename,sal,job,deptno
   from emp
   where deptno=20
