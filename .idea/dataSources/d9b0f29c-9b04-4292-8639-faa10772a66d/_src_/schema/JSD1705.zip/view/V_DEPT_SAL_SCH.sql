create view V_DEPT_SAL_SCH as
select d.deptno,d.dname,max(e.sal) max_sal,min(e.sal) min_sal,avg(e.sal) avg_sal
from emp_sch e,dept_sch d
where e.deptno=d.deptno
group by d.deptno,d.dname
