create view V_EMP_ZMY as
SELECT empno id, ename name, sal salary, deptno 
    FROM emp_ZMY
    WHERE deptno=10
