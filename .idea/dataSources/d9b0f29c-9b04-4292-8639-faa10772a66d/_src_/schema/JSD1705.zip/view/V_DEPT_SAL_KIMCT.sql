create view V_DEPT_SAL_KIMCT as
Select D.Deptno,D.Dname,
       Max(E.Sal) Max_Sal,
       Min(E.Sal) Min_Sal,
       Sum(E.Sal) Sum_Sal,
       Avg(E.Sal) avg_sal
From Emp_Kimct E,Dept_Kimct D
Where E.Deptno = D.Deptno
group by d.deptno,d.dname
