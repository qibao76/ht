create view V_EMP_20_BAI as
SELECT empno,ename,sal,job,deptno FROM emp_bailu
 WHERE deptno=20
