create view VIEW_EMP_DEPTNO_WDD as
select empno,ename,sal,job,deptno from emp_wdd where deptno=20
