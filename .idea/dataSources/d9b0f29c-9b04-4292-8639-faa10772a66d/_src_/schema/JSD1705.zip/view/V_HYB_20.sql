create view V_HYB_20 as
select empno,ename,sal,job,deptno
from hyb
where deptno=20
