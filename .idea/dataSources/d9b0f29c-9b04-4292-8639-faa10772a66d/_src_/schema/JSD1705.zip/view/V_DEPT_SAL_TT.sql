create view V_DEPT_SAL_TT as
select d.dephno,d.dename,
       max(e.sal) max_sal,
       min(e.sal) min_sal,
       sum(e.sal) sum_sal,
       avg(e.sal) avg_sal
from emp_txj e,dept_txj d
where  e.deptno=d.dephno
group by d.dephno,d.dename
