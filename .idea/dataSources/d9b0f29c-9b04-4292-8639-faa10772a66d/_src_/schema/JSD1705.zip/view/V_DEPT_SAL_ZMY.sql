create view V_DEPT_SAL_ZMY as
SELECT e.deptno,d.dname,
        MAX(e.sal) max_sal,
         MIN(e.sal) min_sal,
        SUM(e.sal) sum_sal,
         AVG(e.sal) avg_sal
     FROM emp_ZMY e,dept_ZMY d
     WHERE e.deptno=e.deptno
     GROUP BY e.deptno, d.dname
