create view V_EMP_10_SUZHIPENG as
select empno id,ename name,
       sal salary,deptno
from
 emp
where deptno =10
with read only
