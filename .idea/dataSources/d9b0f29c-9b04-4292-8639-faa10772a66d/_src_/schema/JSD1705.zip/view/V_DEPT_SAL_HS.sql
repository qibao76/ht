create view V_DEPT_SAL_HS as
select d.deptno,d.dname,
       max(e.sal) max_sal,
       min(e.sal) min_sal,
       sum(e.sal) sum_sal,
       avg(e.sal) avg_sal
from emp_hs e,dept_hs d
where e.deptno = d.deptno
group by d.deptno,d.dname
